const jscad = require('@jscad/modeling')
const { cuboid, polygon } = jscad.primitives
const { center, rotateX, translate, translateX } = jscad.transforms
const { intersect, subtract, union } = jscad.booleans
const { measureBoundingBox } = jscad.measurements
const { degToRad } = jscad.utils

const main = () => {
// 1°) Chargement du modèle depuis le fichier 3d
let volume = require('./tete_cheval.obj')

// 2°) placement au centre (centrage, rotation)
volume = center([true,true,true], volume)
volume = rotateX(degToRad(180), volume)

// 3°) ajout du guide
guide = translate([0,0,2], cuboid({size:[12,1,1]}))

// 4°) soustraction du guide au volume
volume = subtract(volume, guide)

// 5°) tranchage
let retour = []
let tranche = cuboid({size:[0.1,100,100]})
let b = measureBoundingBox(volume)
let d = b[1][0]-b[0][0]
let dmax = b[1][1]-b[0][1]
let pas = d/5
for(let i = -d/2 + pas; i < d/2; i += pas){
	retour.push(intersect(volume, translateX(i, tranche)))
}

// 6°) suppression des tranches du bord si trop petites
//retour.shift()
retour.pop()

// 7°) transformation en 2d par projection ...
let r = []
for(i = 0; i < retour.length; i++){
  b = measureBoundingBox(retour[i])
  let o = b[0][0]
  r.push(translate([i *dmax,0*-i*dmax/2,0], union(vol2surf(center([true, true, true],retour[i]), 'x', o))))
}

return r
}

function vol2surf(vol, axe, orig = 0){ // axe = 'x' | 'y' | 'z'
// retourne la surface formee par le volume avec l'axe z (à 0)
let S = [];
let X, Y, Z;

for(let n = 0; n < vol.polygons.length; n++){
  let pts = [];
  let P = vol.polygons[n];
  let ok = true;
  switch(axe){
		case 'x':
			X = 1; Y = 2; Z = 0;
			break;
		case 'y':
			X = 0; Y = 2; Z = 1;
			break;
		case 'z':
			X = 0; Y = 1; Z = 2;
			break;
	}
  for(let i=0; (i < P.vertices.length) && ok; i++){
    let pt = P.vertices[i];
    if(Math.abs(pt[Z] - orig)< 0.05){
      pts.push([pt[X], pt[Y]]);
    } else {
      ok = false;
    }
  }
  if (ok){
    if(axe == 'x'){
			S.push(polygon({points:pts.reverse()}));
		} else {
			S.push(polygon({points:pts}));
		}
  }
}

return S;
}

module.exports = { main }
