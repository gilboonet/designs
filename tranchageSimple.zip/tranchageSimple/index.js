const jscad = require('@jscad/modeling')
const { cuboid } = jscad.primitives
const { center, rotateX, translateX } = jscad.transforms
const { intersect, subtract } = jscad.booleans
const { measureBoundingBox } = jscad.measurements
const { degToRad } = jscad.utils

const main = () => {
// 1°) Chargement du modèle depuis le fichier 3d
let volume = require('./tete_cheval.obj')

// 2°) placement au centre (centrage, rotation)
volume = center([true,true,true], volume)
volume = rotateX(degToRad(180), volume)

// 3°) ajout du guide
guide = cuboid({size:[12,1,1]})

// 4°) soustraction du guide au volume
volume = subtract(volume, guide)

// 5°) tranchage
let retour = []
let tranche = cuboid({size:[0.6,100,100]})
let b = measureBoundingBox(volume)
let d = b[1][0]-b[0][0]
for(let i = -d/2; i < d/2; i = i + d/7){
	retour.push(intersect(volume, translateX(i, tranche)))
}

retour.shift()
retour.pop()

return retour

}
module.exports = { main }
